package org.atmosphere.voidClass;

public class VoidClass {
}
