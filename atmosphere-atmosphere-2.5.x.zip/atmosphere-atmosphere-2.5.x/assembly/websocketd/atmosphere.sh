#!/bin/bash
java -jar target/atmosphere-websocketd-2.1.0-SNAPSHOT-server.jar
